# Zen_D-
Zen_Dé est un mini jeu Démo basé sur des Dés qui consiste a  faire remuer les 2 Dés et à valider deux faces identiques pour remporter la partie

le jeu se joue en binome.
![j1](https://user-images.githubusercontent.com/84296565/159123857-ea809205-cb02-44a3-9fed-fc0d17c1fb58.PNG)

![j2](https://user-images.githubusercontent.com/84296565/159123870-7072aa37-bee6-4128-8aff-6a8746af26ac.PNG)

---> Victoire à faces égales:
![j3](https://user-images.githubusercontent.com/84296565/159123893-0665816a-5e87-4f99-8730-4818c089987b.PNG)
